#
data = []
with open('/home/siva/Documents/valli_project/project2/sample/red.csv') as f1:
    data = f1.read().split('\n')
    print(data)
