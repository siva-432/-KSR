#
import random
import matplotlib.pyplot as plt
from math import exp as e

#BER with Redundancy
import matplotlib.pyplot as plt
import random
y=[]
x=[30000,40000,41000,41300,41500,41600,41650,41680,42541,43600]
for i in range(10):
    num='{0:.2f}'.format(random.uniform(0.1,1))
    y.append(float(num))                         

#print(y,x)
y = [0.56, 0.71, 0.96, 0.8, 0.99, 0.33, 0.9, 0.88, 0.7, 0.33]
def Graph(x,y):    
    plt.scatter(x, y, label="Reliability",color="black",marker="o")
    plt.ylabel("BER")
    plt.xlabel("time in hr")
    plt.title("BER with Redundancy")
    #plt.legend()
    plt.show()
#Graph(x,y)

#Graph(x, y)


