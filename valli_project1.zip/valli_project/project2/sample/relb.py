#
import random
import matplotlib.pyplot as plt
from math import exp as e

#-----------------------Mttdl1-----------------------------------

def Mttdl_Graph1(x,y):
    plt.scatter(x, y, label="Reliability",color="black",marker="o")
    plt.ylabel("MTTDL (50 repairs per a year)")
    plt.xlabel("Failure rate")
    plt.title("MTTDL vs Failure rate with constant repair rate (RAID 1)")
    #plt.legend()
    plt.show()
lis = []
def Mttdl1():
    global l
    l =[0.2,0.4,0.6,0.8,1.0]
    u = 50
    for i in l:
        data = ((3*i) + u)/(2*(i**2))
        lis.append(data)
    return lis


MTTDL1 = Mttdl1()
#print(f'MTTDL = {MTTDL}')
#l =[0.2,0.4,0.6,0.8,]
Mttdl_Graph1(l,MTTDL1)

#-----------------------Mttdl2-----------------------------------

def Mttdl_Graph2(x,y):
    plt.plot(x, y, label="Reliability",color="black",marker="o")
    plt.ylabel("MTTDL (100 repairs per a year)")
    plt.xlabel("Failure rate")
    plt.title("MTTDL vs Failure rate with constant repair rate (RAID 1)")
    #plt.legend()
    plt.show()
lis = []
def Mttdl2():
    global l1
    l1 =[0.2,0.4,0.6,0.8,1.0]
    u = 100
    for i in l1:
        data = ((3*i) + u)/(2*(i**2))
        lis.append(data)
    return lis


MTTDL2 = Mttdl2()
#print(f'MTTDL = {MTTDL}')
#l =[0.2,0.4,0.6,0.8,]
Mttdl_Graph2(l1,MTTDL2)

#-----------------------Mttdl3-----------------------------------

def Mttdl_Graph3(x,y):
    plt.plot(x, y, label="Reliability",color="black",marker="o")
    plt.ylabel("MTTDL (with 1/25 failure rate)")
    plt.xlabel("Failure rate")
    plt.title("MTTDL vs Repair rate with constant failure rate (RAID 1)")
    #plt.legend()
    plt.show()
lis = []
def Mttdl3():
    global l
    l = 0.04
    global u
    u = [0,200,400,600,800,1000]
    for i in u:
        data = ((3*l) + i)/(2*(l**2))
        lis.append(data)
    return lis


MTTDL3 = Mttdl3()
#print(f'MTTDL = {MTTDL}')
#l =[0.2,0.4,0.6,0.8,]
Mttdl_Graph3(u,MTTDL3)

#-----------------------Mttdl4-----------------------------------

def Mttdl_Graph4(x,y):
    plt.plot(x, y, label="Reliability",color="black",marker="o")
    plt.ylabel("MTTDL (with 1/75 failure rate)")
    plt.xlabel("Failure rate")
    plt.title("MTTDL vs Repair rate with constant failure rate (RAID 1)")
    #plt.legend()
    plt.show()
lis = []
def Mttdl4():
    global l
    l = 0.013
    global u1
    u1 = [0,200,400,600,800,1000]
    for i in u1:
        data = ((3*l) + i)/(2*(l**2))
        lis.append(data)
    return lis


MTTDL4= Mttdl4()
#print(f'MTTDL = {MTTDL}')
#l =[0.2,0.4,0.6,0.8,]
Mttdl_Graph4(u1,MTTDL4)
'''Mttdl1= 27027
failure_rate= 1/Mttdl1
print('failure_rate//hour',failure_rate)'''

#Reliability

def R_Graph(x,y):
    plt.plot(x, y, label="Reliability",color="black",marker="o")
    plt.ylabel("Reliability(R(t))")
    plt.xlabel("Time(t) in hr")
    plt.title("MTTDL vs Repair rate with constant failure rate (RAID 1)")
    #plt.legend()
    plt.show()


def Rel():
    l = 0.000024
    #e = 2.71828182846
    rt = []
    time1 = []
    for t in range(0,110000,10000):
        time1.append(t)
        r =e(-(l*t))
        rt.append(r)
    return rt,time1

y1,x1=Rel()
#print(f'Reliability = {y}')
R_Graph(x1,y1)

