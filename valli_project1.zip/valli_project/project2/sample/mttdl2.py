import matplotlib.pyplot as plt
from math import exp as e

#Mttdl
lis = []
def Mttdl():
    global l
    l =[0.1,0.2,0.4,0.6,0.8,1]
    u = 50
    for i in l:
        data = ((3*i) + u)/(2*(i**2))
        lis.append(data)        
    return lis
        
        
MTTDL = Mttdl()
print(f'MTTDL = {MTTDL}')
def Graph(x,y):    
    plt.scatter(x, y, label="Reliability",color="black",marker="o")
    plt.ylabel("MTTDL (100 repairs per a year)")
    plt.xlabel("Failure rate")
    plt.title("MTTDL vs Failure rate with constant repair rate (RAID 1)")
    #plt.legend()
    plt.show()
Graph(l,MTTDL)
