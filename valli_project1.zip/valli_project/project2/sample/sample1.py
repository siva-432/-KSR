#
from relb import *

#Graph(x, y)
Mttdl_Graph1(l,MTTDL1)
Mttdl_Graph2(l1,MTTDL2)
Mttdl_Graph3(u,MTTDL3)
Mttdl_Graph4(u1,MTTDL4)
R_Graph(x1,y1)
