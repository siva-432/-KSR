#
import time
import pandas as pd
import datetime
import random
import matplotlib.pyplot as plt
dt = datetime.datetime.now()
from sample.BER import *

def detect_error(ar, nr):
	n = len(ar)
	res = 0
	# Calculate parity bits again
	for i in range(nr):
		val = 0
		for j in range(1, n + 1):
			if j & (2**i) == (2**i):
				val = val ^ int(ar[-1 * j])
		# Create a binary no by appending
		# parity bits together.
		res = res + val*(10**i)
	# Convert binary to decimal
	#print("Error status is ", res)
	return int(str(res),2)

try:
    with open('/home/siva/Documents/valli_project/project2/sample/red.txt') as f1:
            data1 = f1.read().split('\n')
            red = data1[1:-1]
    with open('/home/siva/Documents/valli_project/project2/data/data.txt') as f2:
            data2 = f2.read().split('\n')
            arr = data2[1:-1]
    neb = ""
    nbt = ""
    stop = 0
    ebr=[]
    time_lapse=[]
    for a, b in zip(arr, red):
        nbt = nbt+str(a)
        start_time = dt.strftime("%f")
        start_time = int(start_time)
        print("Reception data is " + str(a))
        correction = detect_error(str(a), int(b))
        time.sleep(0.1)
        print(" error is " + str(correction))
        code=[]
        if correction > 0:
            for b in str(a):
                code.append(b)
            if code[-correction] == '0':
                code[-correction]='1'
            else:
                code[-correction]='0'
            print(f'Correction data is {code}')
            a = ""
            for s in code:
                a = a+s
            correction = detect_error(str(a), int(b))
            print("The position of error is " + str(correction))
        if int(str(correction), 2) > 0:
            neb = neb+str(correction)
        end_time = dt.strftime("%f")
        end_time = int(end_time)+1
        sec= end_time - start_time
        stop = stop+sec
        print("\n")
        if stop % 10 == 0:
            error_bit_ratio = len(neb)/len(nbt)
            ebr.append(error_bit_ratio)
            time_lapse.append(stop)
            time.sleep(1)

except (IndexError):
	pass

'''finally:
	Graph(x, y)
	time.sleep(2)
	R_Graph(x1,y1)
	time.sleep(2)
	Mttdl_Graph(l,MTTDL)
	time.sleep(2)
	Mttdl_Graph(l1,MTTDL)
	time.sleep(2)
	Mttdl_Graph(u,MTTDL)
	time.sleep(2)
	Mttdl_Graph(u1,MTTDL)'''


'''Graph(x, y)
time.sleep(2)
Mttdl_Graph1(l,MTTDL1)
time.sleep(2)
Mttdl_Graph2(l1,MTTDL2)
time.sleep(2)
Mttdl_Graph3(u,MTTDL3)
time.sleep(2)
Mttdl_Graph4(u1,MTTDL4)
time.sleep(2)
R_Graph(x1,y1)'''
Graph(x, y)
from sample.relb import *






