step 1:
	make sure file path is correct or not
step 2:
	run the encode.py
step 3:
	check the data.csv is created or not
step 4:
	run the decode.py
step 5:
	check all the graphs are generated 
