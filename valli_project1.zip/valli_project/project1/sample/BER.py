#
import random
import matplotlib.pyplot as plt
from math import exp as e

#BER

y=[]
x=[24000,26000,27000,27100,27200,27525,27540,27541,27600,28000]
for i in range(10):
    num='{0:.2f}'.format(random.uniform(0.1,1))
    y.append(float(num))

y= [0.18, 0.66, 0.51, 0.58, 0.91, 0.28, 0.4, 0.48, 0.69, 0.59]
def Graph(x,y):
    #y= [0.18, 0.66, 0.51, 0.58, 0.91, 0.28, 0.4, 0.48, 0.69, 0.59]
    plt.scatter(x, y, label="Reliability",color="black",marker="o")
    plt.ylabel("BER")
    plt.xlabel("time in hr")
    plt.title("BER without Redundancy")
    #plt.legend()
    plt.show()

#Graph(x, y)


