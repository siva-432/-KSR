#
import random
import matplotlib.pyplot as plt
from math import exp as e

#Mttdl

'''def Mttdl_Graph(x,y):
    plt.scatter(x, y, label="Reliability",color="black",marker="o")
    plt.ylabel("MTTDL (100 repairs per a year)")
    plt.xlabel("Failure rate")
    plt.title("MTTDL vs Failure rate with constant repair rate (RAID 1)")
    #plt.legend()
    plt.show()
lis = []
def Mttdl():
    global l
    l =[0.2,0.4,0.6,0.8,1]

    u = 100
    for i in l:
        data = ((3*i) + u)/(2*(i**2))
        lis.append(data)
    return lis


MTTDL = Mttdl()
print(f'MTTDL = {MTTDL}')
#Mttdl_Graph(x,MTTDL)'''

Mttdl1= 27027
failure_rate= 1/Mttdl1
print('failure_rate//hour',failure_rate)

#Reliability

def R_Graph(x,y):
    plt.scatter(x, y, label="Reliability",color="black",marker="o")
    plt.ylabel("Reliability(R(t))")
    plt.xlabel("Time(t) in hr")
    plt.title("Information Reliability Evaluation for IoT without Redundancy")
    #plt.legend()
    plt.show()


def Rel():
    l = 0.000037
    #e = 2.71828182846
    rt = []
    time1 = []
    for t in range(0,110000,10000):
        time1.append(t)
        r =e(-(l*t))
        rt.append(r)
    return rt,time1

y1,x1=Rel()
#print(f'Reliability = {y}')

