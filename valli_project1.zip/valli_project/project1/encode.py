#
import pandas as pd
import time
import csv

# ------------------------------- decimal to binary------------------------------------


def dec_to_binary(mean):
    t_str = ""
    while mean >= 1:
        t_rem = mean%2
        mean = mean//2
        t_str = str(t_rem) + t_str
    return t_str



# _______________________________---------redundancy bits________________________________________


def calcRedundantBits(m):
    i = 1
    while 2**i <= m+i+1:
        i = i+1
    return i


# _______________________________--------redundancy bits position________________________________________


def posRedundantBits(data, r):
    j = 0
    k = 1
    m = len(data)
    res = ''
    for i in range(1, m + r+1):
        if(i == 2**j):
            res = res + '0'
            j += 1
        else:
            res = res + data[-1 * k]
            k += 1
    return res[::-1]

# _______________________________-------calculating redundancy bits________________________________________


def calcParityBits(arr, r):
    n = len(arr)
    for i in range(r):
        val = 0
        for j in range(1, n + 1):
            if (j & (2**i) == (2**i)):
                val = val ^ int(arr[-1 * j])
        arr = arr[:n-(2**i)] + str(val) + arr[n-(2**i)+1:]
    return arr

# ----------------------------------------- extarcting data from csv file-----------------------------------

try:
    df = pd.read_csv("Air_Quality_test.csv")
    temp = df["temp"]
    count = len(temp)
    print(len(temp))
    step = 1
    start = 0
    stop = 10
    mean = 0
    while count > 0:
        for i in range(start, stop):
            print(temp[i])
            mean = mean+temp[i]
            count -= 1
        mean = round(mean // 10)
        avg = mean
        t_data = dec_to_binary(avg)
        data = t_data
        m = len(data)
        r = calcRedundantBits(m)
        red = r
        try:
            with open('/home/siva/Documents/valli_project/red.csv', mode='a') as red_file:
                writer = csv.writer(red_file, quoting=csv.QUOTE_MINIMAL)
                writer.writerow([str(red)])
            with open('backup/red.csv', mode='a') as red_file:
                writer = csv.writer(red_file, quoting=csv.QUOTE_MINIMAL)
                writer.writerow([str(red)])
        except:
            print("Error occured at Redundancy ")
        finally:
            red_file.close()
        arr = posRedundantBits(data, r)
        arr = calcParityBits(arr, r)
        print(f"Transmitted data is {arr}")
        try:
            with open('/home/siva/Documents/valli_project/project1/data/data.csv', mode='a') as csv_file:
                writer = csv.writer(csv_file, quoting = csv.QUOTE_MINIMAL)
                writer.writerow([str(arr)])
                print("\t\tData transmitted successfully")
            with open('backup/data.csv', mode='a') as csv_file:
                writer = csv.writer(csv_file, quoting = csv.QUOTE_MINIMAL)
                writer.writerow([str(arr)])
                print("\t\tData transmitted successfully")
        except:
            print("\t\t******Transmission Failed*******")
        finally:
            csv_file.close()
        print("\n")
        start += 10
        stop += 10
except:
    print("Mean is not calculated to remaining data coz of no.of data should be greater than length of 10")
finally:
    print("\t\t\t\t\t\t\t\t\t__________________________")
    print("\t\t\t\t\t\t\t\t\t| Data processed greatly |")
    print("\t\t\t\t\t\t\t\t\t--------------------------")





