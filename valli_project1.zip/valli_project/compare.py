#
with open('/home/siva/Documents/valli_project/project2/data/data.csv') as f1:
    d1 = f1.read().split('\n')
    d1 = d1[1:-1]
with open('/home/siva/Documents/backup/data.csv') as f2:
    d2 = f2.read().split('\n')
    d2 = d1[1:-1]

for i,j in zip(d1,d2):
    if i == j:
        print("not hacked")
    else :
        print('------------------>hacked')
